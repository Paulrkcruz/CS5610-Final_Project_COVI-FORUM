import React from 'react';

export default function Preferences() {
  return(
    <h2>Preferences</h2>
  );
}
