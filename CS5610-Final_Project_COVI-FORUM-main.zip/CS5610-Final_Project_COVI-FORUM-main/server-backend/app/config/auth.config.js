module.exports = {
  secret: "coviforum-secret-key"
};
